import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add appointment
    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Invalid appointment or duplicate ID");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Delete appointment by ID
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointments.remove(appointmentId);
    }

    // Optional: Get appointment (helpful for testing or future UI)
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
}
