import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
        appointment = new Appointment("A1", getFutureDate(), "Checkup");
        service.addAppointment(appointment);
    }

    @Test
    public void testAddAppointmentValid() {
        Appointment appt2 = new Appointment("A2", getFutureDate(), "Dentist");
        service.addAppointment(appt2);
        assertEquals(appt2, service.getAppointment("A2"));
    }

    @Test
    public void testAddDuplicateAppointment() {
        Appointment duplicate = new Appointment("A1", getFutureDate(), "Duplicate");
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(duplicate));
    }

    @Test
    public void testAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    public void testDeleteAppointmentValid() {
        service.deleteAppointment("A1");
        assertNull(service.getAppointment("A1"));
    }

    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NonExistent"));
    }

    @Test
    public void testGetAppointment() {
        assertEquals(appointment, service.getAppointment("A1"));
        assertNull(service.getAppointment("UnknownID"));
    }
}
