import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    // Helper method to get a future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    @Test
    public void testValidAppointmentCreation() {
        Appointment appt = new Appointment("A123", getFutureDate(), "Doctor Visit");
        assertEquals("A123", appt.getAppointmentId());
        assertEquals("Doctor Visit", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    public void testAppointmentIdNullOrTooLong() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", future, "Desc"));
    }

    @Test
    public void testAppointmentDateNullOrPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // past date
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", pastDate, "Desc"));
    }

    @Test
    public void testDescriptionNullOrTooLong() {
        Date future = getFutureDate();
        String longDesc = "This description is definitely way too long to be accepted as valid.";
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", future, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", future, longDesc));
    }

    @Test
    public void testSettersValidations() {
        Appointment appt = new Appointment("A1", getFutureDate(), "Desc");

        // Test valid setter
        Date newDate = getFutureDate();
        appt.setAppointmentDate(newDate);
        assertEquals(newDate, appt.getAppointmentDate());

        appt.setDescription("New Description");
        assertEquals("New Description", appt.getDescription());

        // Test invalid setter inputs
        Date pastDate = new Date(System.currentTimeMillis() - 100000);
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate));
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(null));
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null));
        String longDesc = "This description is definitely way too long to be accepted as valid.";
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(longDesc));
    }
}
