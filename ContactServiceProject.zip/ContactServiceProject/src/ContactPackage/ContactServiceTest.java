import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddValidContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertEquals(contact, service.getContact("001"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("001", "Jane", "Smith", "0987654321", "456 Oak Ave"));
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.deleteContact("001");
        assertNull(service.getContact("001"));
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateFirstName("001", "Jane");
        service.updateLastName("001", "Smith");
        service.updatePhone("001", "0987654321");
        service.updateAddress("001", "456 Oak Ave");

        Contact updated = service.getContact("001");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("456 Oak Ave", updated.getAddress());
    }

    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "NoName");
        });
    }
}
