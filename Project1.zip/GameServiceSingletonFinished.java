package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu 
 * and Shane Edge
 */ 


// Class for entities
class Entity{
	private long id;
	private String name;

	public Entity(long id, String name){
		this.id = id;
		this.name = name;
	}
	public long getId(){
		return id;
	}
	public String getName(){
		return name;
	}
}
// Player class inherits from Entity
class Player extends Entity {
    public Player(long id, String name) {
        super(id, name);
    }
}
// Team class inherits from Entity
class Team extends Entity {
    public Team(long id, String name) {
        super(id, name);
    }
}
class Game extends Entity{
	private List<Team> teams = new ArrayList<>();
	private List<Player> players = new ArrayList<>();

	public Game(long id, String name){
		super(id, name);
	}
	public void addTeam(Team team){
		team.add(team);
	}
	public void addPlayer(Player player){
		players.add(player);
	}
	public boolean isTeamNameTaken(String name){
		return team.stream()anyMatcj(team -> team.getName().equals(name));
	}
	public boolean isPlayerNameTaken(String name){
        return players.stream().anyMatch(player -> player.getName().equals(name));
    }
	//method to get teams in the game
    public List<Team> getTeams(){
        return teams;
    }
	//method to get players in the game
    public List<Player> getPlayers(){
        return players;
    }
}
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// Singleton instance
    private static GameService instance;

    // Private constructor to prevent instantiation
    private GameService() {
    }

    /**
     * Returns the singleton instance of GameService
     * 
     * @return the singleton instance
     */
    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }



	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		for (Game existingGame : games) {
            if (existingGame.getName().equals(name)) {
                return existingGame; // Return existing instance if found
            }
        }

        // If not found, make a new game instance and add it to the list of games
        Game game = new Game(nextGameId++, name);
        games.add(game);

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {
		for (Game existingGame : games) {
			if (existingGame.getId() == id) {
				return existingGame; // Return existing instance if found
			}
		}
		return null; // Return null if no game with the specified ID is found
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// Use iterator to look for an existing game with the same name
        for (Game existingGame : games) {
            if (existingGame.getName().equals(name)) {
                return existingGame; // Return existing instance if found
            }
        }
		//if not found, return null
		return null;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
